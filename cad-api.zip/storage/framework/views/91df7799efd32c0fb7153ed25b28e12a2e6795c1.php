<?php $__env->startSection('content'); ?>
    <?php if(isset($login)): ?>
        <div class="col-xl-4 col-lg-5 col-md-7 col-sm-9 col-10 mx-auto my-5 mt-5">
            <div style="font-size: 1.7rem" class="text-lead font-weight-bold my-3">
                Login
            </div>
            <form action="/login_user" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(count($errors) > 0): ?>
                    <div class="error-msg p-3">
                        <div class="per-error">
                            <?php echo e($errors->first('username')); ?>

                        </div>
                        <div class="per-error">
                            <?php echo e($errors->first('password')); ?>

                        </div>
                        <div class="per-error">
                            <?php echo e($errors->first('login')); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <div class="mb-3">
                    <label for="username" class="form-label">User Name</label>
                    <input type="text" class="form-control" name="username">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password">
                </div>

                <div class="mb-3">
                    <button type="submit" class="btn px-5 btn-dark">Login</button>
                </div>

                <div class="upgrade mt-3">
                    Don't Have An Account ? <a href="<?php echo e(URL::to('/register')); ?>">Register</a>
                </div>
            </form>
        </div>
    <?php endif; ?>


    <?php if(isset($register)): ?>
        <div class="col-xl-4 col-lg-5 col-md-7 col-sm-9 col-10 mx-auto my-5 mt-5">
            <div style="font-size: 1.7rem" class="text-lead font-weight-bold my-3">
                Register
            </div>
            <form action="/create_user" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(count($errors) > 0): ?>
                    <div class="error-msg p-3">
                        <div class="per-error">
                            <?php echo e($errors->first('fullname')); ?>

                        </div>
                        <div class="per-error">
                            <?php echo e($errors->first('username')); ?>

                        </div>
                        <div class="per-error">
                            <?php echo e($errors->first('password')); ?>

                        </div>
                        <div class="per-error">
                            <?php echo e($errors->first('email')); ?>

                        </div>
                        <div class="per-error">
                            <?php echo e($errors->first('user_type')); ?>

                        </div>
                    </div>
                <?php endif; ?>


                <div class="mb-3">
                    <label for="fullname" class="form-label">Full Name</label>
                    <input type="text" class="form-control" name="fullname" id="fullname" required>
                </div>
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" class="form-control" id="email" name="email" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" id="password" required>
                </div>

                <div class="row">
                    <label for="password" class="form-label">User Type</label>
                    <div class="col-3 mb-3 pl-3 form-check">
                        
                        <input type="radio" class="form-check-input ml-3" name="user_type" id="adminCheck" value="admin"
                            id="adminCheck" required>
                        <label class="form-check-label" for="adminCheck">Admin</label>
                    </div>


                    <div class="col-3 mb-3 form-check">
                        
                        <input type="radio" class="form-check-input" name="user_type" value="user" id="freeUserCheck"
                            required>
                        <label class="form-check-label" for="freeUserCheck"> User</label>
                    </div>
                </div>

                <div class="mb-3">
                    <button type="submit" class="btn my-3 px-5 btn-dark">Register</button>
                </div>

                <div class="upgrade mt-3">
                    Already Have An Account ? <a href="<?php echo e(URL::to('/login')); ?>">Login</a>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <?php if(isset($index)): ?>
        <div class="text-muted user-type display-4 mt-5">
            HOMEPAGE
            <div class="upgrade mt-3">
                <a href="<?php echo e(URL::to('/login')); ?>">Login</a> <span style="font-size: 1rem !important">|</span> <a href="<?php echo e(URL::to('/register')); ?>">Register</a>
            </div>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\cad-api\resources\views/index.blade.php ENDPATH**/ ?>