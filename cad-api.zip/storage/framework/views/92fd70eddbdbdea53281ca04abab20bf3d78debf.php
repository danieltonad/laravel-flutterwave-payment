

<?php $__env->startSection('content'); ?>
    <div class="col-lg-8 col-md-10 col-11 mx-auto my-5 mt-3">



        

        <?php if($user->user_type == ADMIN): ?>
            <div style="font-size: 2rem" class="title text-lead mt-4">
                Hi Admin,
            </div>
            <div class="container-fluid my-3 mt-5">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Full Name</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">User Type</th>
                        </tr>
                    </thead>




                    <tbody>
                        <?php if(count($user_list) > 0): ?>
                            <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($users->id); ?></th>
                                    <td><?php echo e($users->fullname); ?></td>
                                    <td><?php echo e($users->username); ?></td>
                                    <td><?php echo e($users->email); ?></td>
                                    <td><?php echo e(userType($users->user_type)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <th colspan="5" scope="row">
                                    User List Empty
                                </th>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <?php if($user->user_type == PAID_USER): ?>
            <div style="font-size: 1.5rem" class="title text-grey mt-4">
                Hi <?php echo e($user->fullname); ?>,
            </div>
            <div class="text-muted user-type display-4">
                PAID USER
            </div>
        <?php endif; ?>

        <?php if($user->user_type == FREE_USER): ?>
            <div style="font-size: 1.5rem" class="title text-lead mt-4">
                Hi <?php echo e($user->fullname); ?>,
            </div>
            <div class="text-muted user-type ">
                <div class="display-4">FREE USER</div>

                <div class="upgrade mt-3">
                    <a href="<?php echo e(URL::to('upgrade/')); ?>">Upgrade Plan</a>
                </div>
                

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\cad-api\resources\views/dashboard.blade.php ENDPATH**/ ?>