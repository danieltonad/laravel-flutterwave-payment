

<?php $__env->startSection('content'); ?>
    <div class="col-lg-8 col-md-10 col-11 mx-auto my-5 mt-3">

        <div class="display-4 text-muted user-type">
            <?php echo e($message); ?>

        </div>

        
        <script>
            setTimeout(() => {
                window.location.replace('/dashboard');
            }, 1000);
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\cad-api\resources\views/verify_payment.blade.php ENDPATH**/ ?>