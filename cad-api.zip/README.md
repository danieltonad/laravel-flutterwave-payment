# Simple Payment Integeration [FlutterWave]

## Test Card
 Card No: 5531886652142950	
 CVV: 564	
 PIN: 3310
 MM/YY: 09/32
 OTP: 12345